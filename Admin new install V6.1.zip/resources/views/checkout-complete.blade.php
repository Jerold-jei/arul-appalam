Order ID : {{$order_id}} -- payment done
